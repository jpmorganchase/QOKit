# QAOA Objective Verifier

Standalone C++ tool for verifying QAOA objective values (satisfaction fractions)
on D-regular Max-k-XORSAT, using the Basso/Villalonga branch tensor contraction
with double-double precision.

Companion to [arXiv:2604.24633](https://arxiv.org/abs/2604.24633).

Extracted from [QOKit](https://github.com/jpmorganchase/QOKit).

## Requirements

- C++17 compiler (GCC, Clang, or AppleClang)
- CMake 3.16+
- make

## Build & Run

```bash
make
./cpp/build/verify qaoa_data/qaoa_angles_for_verifier.csv
```

Or in one step:

```bash
make verify
```

## CLI Mode

Verify a single configuration:

```bash
./cpp/build/verify --k 3 --D 4 --gamma "0.42;0.72" --beta "0.36;0.21" --objective 0.739122784001
```

## Angle Convention

- Phase separator: `exp(-i * gamma * Z^k)`
- Mixer: `Rx(2*beta)`

## Options

- `--precision dd` (default) — double-double (~32 digits)
- `--precision float64` — standard IEEE double (faster, sufficient for p < 12)

## CSV Format

```
# Lines starting with # are skipped
k,D,p,objective,source,gamma,beta
2,3,1,0.692450089730,qokit-cpp-dd,-0.307739854334912,0.392699081584979
3,4,2,0.739122784001,qokit-cpp-dd,-0.211215101730586;-0.360594429029972,0.363591846566196;0.211466412652256
```

Angles use `;` as separator for multiple depth values.
