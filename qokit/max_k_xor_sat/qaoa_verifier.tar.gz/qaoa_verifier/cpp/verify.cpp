/**
 * QAOA Objective Verifier
 *
 * Reads a CSV of pre-computed QAOA angles and verifies each objective
 * (satisfaction fraction) by recomputing it via the Basso/Villalonga
 * branch tensor contraction (double-double precision by default).
 *
 * Companion to arXiv:2604.24633
 *
 * Usage:
 *   ./verify angles.csv
 *   ./verify angles.csv --precision float64
 *   ./verify --k 3 --D 4 --p 2 --gamma "0.42;0.72" --beta "0.36;0.21"
 *
 * CSV format (lines starting with # are skipped):
 *   k,D,p,objective,source,gamma,beta
 *   (gamma and beta fields use ; as separator for multiple depth values)
 *
 * Angle convention:
 *   Phase separator: exp(-i * gamma * Z^k)
 *   Mixer:          Rx(2*beta)
 */

#include "contract.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <chrono>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>

struct VerificationRow {
    int k, D, p;
    double objective_claimed;
    std::string source;
    std::vector<double> gamma;
    std::vector<double> beta;
};

static std::vector<double> parse_angles(const std::string& field) {
    std::vector<double> vals;
    std::istringstream ss(field);
    std::string token;
    while (std::getline(ss, token, ';')) {
        if (!token.empty()) vals.push_back(std::stod(token));
    }
    return vals;
}

static std::string trim(const std::string& s) {
    size_t start = s.find_first_not_of(" \t\r\n");
    if (start == std::string::npos) return "";
    size_t end = s.find_last_not_of(" \t\r\n");
    return s.substr(start, end - start + 1);
}

static std::vector<VerificationRow> parse_csv(const std::string& filepath) {
    std::vector<VerificationRow> rows;
    std::ifstream file(filepath);
    if (!file.is_open()) {
        fprintf(stderr, "Error: cannot open '%s'\n", filepath.c_str());
        return rows;
    }

    std::string line;
    while (std::getline(file, line)) {
        std::string stripped = trim(line);
        if (stripped.empty() || stripped[0] == '#') continue;

        // Split on comma (7 fields: k,D,p,objective,source,gamma,beta)
        std::vector<std::string> fields;
        std::istringstream ss(stripped);
        std::string field;
        while (std::getline(ss, field, ',')) {
            fields.push_back(field);
        }
        if (fields.size() < 7) continue;

        VerificationRow row;
        row.k = std::stoi(fields[0]);
        row.D = std::stoi(fields[1]);
        row.p = std::stoi(fields[2]);
        row.objective_claimed = std::stod(fields[3]);
        row.source = fields[4];
        row.gamma = parse_angles(fields[5]);
        row.beta = parse_angles(fields[6]);

        if ((int)row.gamma.size() != row.p || (int)row.beta.size() != row.p) {
            fprintf(stderr, "Warning: k=%d D=%d p=%d has mismatched angle lengths, skipping.\n",
                    row.k, row.D, row.p);
            continue;
        }
        rows.push_back(row);
    }
    return rows;
}

static double compute_objective(const std::vector<double>& gamma,
                                const std::vector<double>& beta,
                                int p, int D, int k, bool use_dd) {
    double expectation = contract_symmetric_tree(gamma.data(), beta.data(),
                                                  p, D, k, use_dd, false);
    return (1.0 - expectation) / 2.0;
}

static const char* problem_label(int k) {
    static char buf[32];
    if (k == 2) return "MaxCut";
    snprintf(buf, sizeof(buf), "Max-%d-XORSAT", k);
    return buf;
}

static void print_separator(int width) {
    for (int i = 0; i < width; i++) putchar('-');
    putchar('\n');
}

static int run_csv(const std::string& filepath, bool use_dd) {
    printf("========================================================================\n");
    printf("  QAOA Objective Verifier\n");
    printf("  Companion to arXiv:2604.24633\n");
    printf("========================================================================\n\n");
    printf("Reading angles from: %s\n", filepath.c_str());
    printf("Precision: %s\n\n", use_dd ? "double-double" : "float64");

    auto rows = parse_csv(filepath);
    if (rows.empty()) {
        printf("No valid rows found.\n");
        return 1;
    }

    printf("Found %zu configurations to verify.\n", rows.size());
    print_separator(100);

    int n_ok = 0, n_mismatch = 0, n_fail = 0;

    for (const auto& row : rows) {
        auto t0 = std::chrono::high_resolution_clock::now();
        double obj = compute_objective(row.gamma, row.beta, row.p, row.D, row.k, use_dd);
        auto t1 = std::chrono::high_resolution_clock::now();
        double elapsed = std::chrono::duration<double>(t1 - t0).count();

        if (std::isnan(obj) || !std::isfinite(obj)) {
            printf("  (k=%d, D=%d, p=%2d) [%-16s]  obj=NaN/Inf                       FAIL     [%.1fs]\n",
                   row.k, row.D, row.p, problem_label(row.k), elapsed);
            n_fail++;
            continue;
        }

        double diff = std::abs(obj - row.objective_claimed);
        const char* status = diff < 1e-6 ? "OK" : "MISMATCH";

        printf("  (k=%d, D=%d, p=%2d) [%-16s]  obj=%.12f  claimed=%.12f  delta=%.2e  %s  [%.1fs]\n",
               row.k, row.D, row.p, problem_label(row.k),
               obj, row.objective_claimed, diff, status, elapsed);

        if (diff < 1e-6) n_ok++;
        else n_mismatch++;
    }

    print_separator(100);
    printf("\nResults: %d OK, %d MISMATCH, %d FAIL (out of %zu total)\n",
           n_ok, n_mismatch, n_fail, rows.size());

    if (n_fail == 0 && n_mismatch == 0) {
        printf("\n  All %zu evaluations verified successfully.\n\n", rows.size());
        return 0;
    }
    return 1;
}

static int run_cli(int k, int D, const std::vector<double>& gamma,
                   const std::vector<double>& beta, double obj_claimed,
                   bool has_claimed, bool use_dd) {
    int p = (int)gamma.size();

    printf("========================================================================\n");
    printf("  QAOA Objective Verifier\n");
    printf("========================================================================\n\n");

    auto t0 = std::chrono::high_resolution_clock::now();
    double obj = compute_objective(gamma, beta, p, D, k, use_dd);
    auto t1 = std::chrono::high_resolution_clock::now();
    double elapsed = std::chrono::duration<double>(t1 - t0).count();

    printf("  (k=%d, D=%d, p=%2d) [%-16s]  obj=%.12f", k, D, p, problem_label(k), obj);
    if (has_claimed) {
        double diff = std::abs(obj - obj_claimed);
        printf("  claimed=%.12f  delta=%.2e  %s",
               obj_claimed, diff, diff < 1e-6 ? "OK" : "MISMATCH");
    }
    printf("  [%.1fs]\n\n", elapsed);

    return 0;
}

static void usage(const char* prog) {
    fprintf(stderr, "Usage:\n");
    fprintf(stderr, "  %s <angles.csv> [--precision dd|float64]\n", prog);
    fprintf(stderr, "  %s --k K --D D --gamma g1;g2;... --beta b1;b2;... [--objective X] [--precision dd|float64]\n\n", prog);
    fprintf(stderr, "Angle convention: phase = exp(-i*gamma*Z^k), mixer = Rx(2*beta)\n\n");
    fprintf(stderr, "CSV format (# lines are skipped):\n");
    fprintf(stderr, "  k,D,p,objective,source,gamma,beta\n");
    fprintf(stderr, "  (gamma and beta use ; as separator)\n");
}

int main(int argc, char** argv) {
    if (argc < 2) {
        usage(argv[0]);
        return 1;
    }

    // Parse arguments
    std::string csv_path;
    int k = 0, D = 0;
    std::vector<double> gamma, beta;
    double obj_claimed = 0.0;
    bool has_claimed = false;
    bool use_dd = true;  // default to DD for verification

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--k") == 0 && i + 1 < argc) {
            k = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--D") == 0 && i + 1 < argc) {
            D = atoi(argv[++i]);
        } else if (strcmp(argv[i], "--gamma") == 0 && i + 1 < argc) {
            gamma = parse_angles(argv[++i]);
        } else if (strcmp(argv[i], "--beta") == 0 && i + 1 < argc) {
            beta = parse_angles(argv[++i]);
        } else if (strcmp(argv[i], "--objective") == 0 && i + 1 < argc) {
            obj_claimed = std::stod(argv[++i]);
            has_claimed = true;
        } else if (strcmp(argv[i], "--precision") == 0 && i + 1 < argc) {
            std::string prec = argv[++i];
            use_dd = (prec == "dd");
        } else if (strcmp(argv[i], "--help") == 0 || strcmp(argv[i], "-h") == 0) {
            usage(argv[0]);
            return 0;
        } else if (argv[i][0] != '-') {
            csv_path = argv[i];
        } else {
            fprintf(stderr, "Unknown option: %s\n", argv[i]);
            usage(argv[0]);
            return 1;
        }
    }

    // CSV mode
    if (!csv_path.empty()) {
        return run_csv(csv_path, use_dd);
    }

    // CLI mode
    if (k > 0 && D > 0 && !gamma.empty() && !beta.empty()) {
        if (gamma.size() != beta.size()) {
            fprintf(stderr, "Error: gamma and beta must have the same length.\n");
            return 1;
        }
        return run_cli(k, D, gamma, beta, obj_claimed, has_claimed, use_dd);
    }

    fprintf(stderr, "Error: provide a CSV file or --k, --D, --gamma, --beta.\n");
    usage(argv[0]);
    return 1;
}
